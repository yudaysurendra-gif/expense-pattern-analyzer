# Expense Pattern Analyzer

Analyzes personal expense data to find spending patterns, trends, unusual expenses and budget overruns.

## Setup
    pip install -r requirements.txt
    python expense_analyzer.py                  # runs on auto-generated sample data
    python expense_analyzer.py my_expenses.csv  # runs on your own data

## CSV format
    date,category,amount,description
    2026-10-01,Food,250,Lunch

## Features
- Spending by category (with % share)
- Monthly trend and next-month forecast (linear regression)
- Average spending by weekday
- Anomaly detection using z-score
- Budget alerts (edit BUDGETS in the code)
- Dashboard chart saved to output/expense_report.png
